#include <stdio.h>
#include <stdlib.h>
#include "arvoreAVL.h"

int main(){
    int x, c, id;
    ArvAVL *raiz;
    raiz = cria_arvAVL();

	raiz = cria_arvAVL();

	if(vazia_arvAVL(raiz)){
	   printf("Arvore Vazia");
	}else{
		printf("Arvore possui elementos");
	}

	for(c = 100; c<200; c+=10){
		x = insere_arvAVL(raiz, c);
		if(x){
			printf("Elemento inserido com sucesso!\n");
		}else{
			printf("Elemento não inserido!!\n");
		}
	}
	
	printf("Busca na Arvore AVL: \n");
	printf("Qual ID deseja pesquisar: ");
	scanf("%d, &id");
	
	if(consulta_arvAVL(raiz, id)){
		printf("Consulta realizada com sucesso!\n");
	}else{
		printf("Elemento nao encontrado!");
	}

	printf("\n");

	x = totalNO_arvAVL(raiz);
	printf("O total de nos e %d\n", x);

	preOrdem_arvAVL(raiz);

	emOrdem_arvAVL(raiz);

	posOrdem_arvAVL(raiz);

	printf("Qual ID deseja Remover: ");
	scanf("%d, &id");
	x = remove_arvAVL(raiz, id);
	if(x){
		printf("Elemento removido com sucesso!\n");
	}else{
		printf("Elemento não removido!!\n");
	}
	
	

	
}


}



