typedef struct NO *ArvAVL;

ArvAVL *cria_arvAVL();

void liberar_arvAVL(ArvAVL *raiz);

struct NO *procuramenor(struct NO *atual);

int fatorBalanceamento_NO(struct NO *no);

int vazia_arvAVL(ArvAVL *raiz);

int altura_arvAVL(ArvAVL *raiz);

int totalNO_arvAVL(ArvAVL *raiz);

void preOrdem_arvAVL(ArvAVL *raiz);

void emOrdem_arvAVL(ArvAVL *raiz);

void posOrdem_arvAVL(ArvAVL *raiz);

int insere_arvAVL(ArvAVL *raiz, int valor);

int remove_arvAVL(ArvAVL *raiz, int valor);

int consulta_arvAVL(ArvAVL *raiz, int valor);

int insere_ArvAVL(ArvAVL *raiz, int valor);

