typedef struct NO *arvoreLLRB;

int cor(struct NO *H);

void trocaCor(struct NO *H);
