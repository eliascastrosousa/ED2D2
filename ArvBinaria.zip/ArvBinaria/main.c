#include <stdio.h>
#include <stdlib.h>
#include "arvoreBinaria.h"

int main(){
    int x;
    ArvBin *raiz;
    raiz = cria_arvBin();
}

if(vazia_arvBin(raiz)){
   printf("Arvore Vazia");
}else{
    printf("Arvore possui elementos");
}
printf("\n");

x = totalNO_arvBin(raiz);
printf("O total de nos e %d\n", x);

preOrdem_arvBin(raiz);

emOrdem_arvBin(raiz);

posOrdem_arvBin(raiz);

raiz = cria_arvBin();

x = insere_arvBin(raiz, 150);
x = insere_arvBin(raiz, 110);
x = insere_arvBin(raiz, 100);
x = insere_arvBin(raiz, 130);
x = insere_arvBin(raiz, 120);
x = insere_arvBin(raiz, 140);
x = insere_arvBin(raiz, 160);

x = remove_arvBin(raiz, 100);

printf("Busca na Arvore Binaria: \n");
if(consulta_arvBin(raiz, 140)){
	printf("Consulta realizada com sucesso!\n");
}else{
	printf("Elemento nao encontrado!");
}





